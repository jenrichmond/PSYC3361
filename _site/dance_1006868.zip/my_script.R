# Script written during the "dplyr" module
# Author: Danielle Navarro


# set up ------------------------------------------------------------------

# load packages
library(tidyverse)

# read the data
swow <- read_tsv("data_swow.csv.zip")
swow <- swow %>% mutate(id = 1:n())

# clean the names
swow <- swow %>%
  rename(n_response = R1, n_total = N, strength = R1.Strength)




# extract four association data frames ------------------------------------


# forward associations for woman
woman_fwd <- swow %>%
  filter(cue == "woman", n_response > 1) %>%
  select(cue, response, strength, id) %>% 
  mutate(
    rank = rank(-strength),
    type = "forward",
    word = "woman",
    associate = response
  )

# backward associations for woman
woman_bck <- swow %>%
  filter(response == "woman", n_response > 1) %>%
  arrange(desc(strength)) %>%
  select(-n_response, -n_total) %>% 
  mutate(
    rank = rank(-strength),
    type = "backward",
    word = "woman",
    associate = cue
  )

# forward associations for man
man_fwd <- swow %>%
  filter(cue == "man", n_response > 1) %>% 
  select(cue, response, strength, id) %>% 
  mutate(
    rank = rank(-strength),
    type = "forward",
    word = "man",
    associate = response
  )

# backward associations for man
man_bck <- swow %>%
  filter(response == "man", n_response > 1) %>%
  arrange(desc(strength)) %>% 
  select(-starts_with("n_")) %>% 
  mutate(
    rank = rank(-strength),
    type = "backward",
    word = "man",
    associate = cue
  )


# bind the variables together ---------------------------------------------

gender <- bind_rows(
  man_bck, man_fwd, woman_bck, woman_fwd
) %>% 
  select(id:associate) %>% 
  filter(associate != "man", associate != "woman")


# pivot forward associations ----------------------------------------------

gender_fwd <- gender %>% 
  filter(type == "forward") %>% 
  pivot_wider(
    id_cols = associate,
    names_from = word,
    values_from = rank
  ) %>% 
  mutate(
    woman = (1/woman) %>% replace_na(0),
    man = (1/man) %>% replace_na(0),
    diff = woman - man
  )

ggplot(data = gender_fwd) + 
  geom_col(mapping = aes(
    y = diff, 
    x = associate %>% reorder(diff)
  )) + 
  coord_flip()










