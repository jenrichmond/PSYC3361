# the frames data
# danielle 
# blah 

# load pacakge
library(tidyverse)

frames <- read_csv(file = "data_reasoning.csv")

by_item <- frames %>%
  group_by(test_item) %>%
  summarise(
    mean_response = mean(response),
    sd_response = sd(response),
    n_response = n()
  )

pic <- ggplot(
  data = by_item,
  mapping = aes(
    x = test_item, 
    y = mean_response
  )
) +
geom_point()

pic + theme_dark()
pic + theme_minimal()

